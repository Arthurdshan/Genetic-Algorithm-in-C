#ifndef __GENETIC_ALGORITHM_H__
#define __GENETIC_ALGORITHM_H__

#include "algorithms.h"
#include "ga.h"
#include "helpers.h"
#include "types.h"

#endif